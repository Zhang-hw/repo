## 智慧路灯后台系统

数据库文件：
renren-admin/db/streetlamp.sql

登录账户：
账户名admin 密码admin
